import re

from src.processing.prospectus.person_record import (
    PersonRecord,
)


class PersonExtractor:
    """
    Extracts structured people information
    from prospectus sections.
    """

    TITLE_PATTERN = re.compile(
        r"\b("
        r"Prof\.?|Professor|"
        r"Dr\.?|"
        r"Mr\.?|Mrs\.?|Ms\.?|"
        r"Engr\.?"
        r")\b",
        re.IGNORECASE,
    )

    # DEGREE_PATTERN = re.compile(
    #     r"\b("
    #     r"BE|B\.E\.|"
    #     r"BS|B\.S\.|"
    #     r"ME|M\.E\.|"
    #     r"MS|M\.S\.|"
    #     r"MBA|"
    #     r"MPhil|"
    #     r"Ph\.?D|"
    #     r"PhD"
    #     r")\b",
    #     re.IGNORECASE,
    # )

    ROLE_PATTERN = re.compile(
        r"\b("
        r"Vice Chancellor|"
        r"Pro[- ]?Vice Chancellor|"
        r"Dean|"
        r"Chairman|"
        r"Chairperson|"
        r"Director|"
        r"Registrar|"
        r"Treasurer|"
        r"Controller of Examinations|"
        r"Professor|"
        r"Associate Professor|"
        r"Assistant Professor|"
        r"Lecturer"
        r")\b",
        re.IGNORECASE,
    )

    def extract(
        self,
        pages: list[dict],
    ) -> list[PersonRecord]:

        records: list[PersonRecord] = []

        for page in pages:

            page_number = page["page_number"]

            for section in page.get(
                "sections",
                [],
            ):

                heading = section.get(
                    "heading",
                    "",
                ).strip()

                records.extend(
                    self._extract_people(
                        section=section,
                        page_number=page_number,
                        heading=heading,
                    )
                )

        return self._deduplicate(records)

    def _deduplicate(
        self,
        records: list[PersonRecord],
    ) -> list[PersonRecord]:

        merged: dict[str, PersonRecord] = {}

        for record in records:

            key = re.sub(
                r"\s+",
                " ",
                record.name.lower(),
            ).strip()

            existing = merged.get(key)

            if existing is None:
                merged[key] = record
                continue

            # Prefer a discovered role.
            if existing.role is None and record.role:
                existing.role = record.role

            # Prefer a discovered department.
            if existing.department is None and record.department:
                existing.department = record.department

            # Merge qualifications.
            for qualification in record.qualifications:
                if qualification not in existing.qualifications:
                    existing.qualifications.append(
                        qualification
                    )

        return list(merged.values())
    
    def _normalize_person_name(
        self,
        line: str,
    ) -> str:

        text = line.strip()

        text = re.sub(
            r"^\d+\.\s*",
            "",
            text,
        )

        text = re.sub(
            r"^[ivxlcdmIVXLCDM]+\)\s*",
            "",
            text,
        )

        text = re.sub(
            r"^[A-Za-z]\)\s*",
            "",
            text,
        )

        # Collapse whitespace.
        text = re.sub(
            r"\s+",
            " ",
            text,
        )

        # Remove trailing punctuation.
        text = text.strip(
            " ,;:-."
        )

        return text.strip()
    
    def _extract_department(
        self,
        heading: str,
        section: dict,
    ) -> str | None:
        """
        Extract a department/faculty name
        from the section heading.
        """

        heading = heading.strip()

        if not heading:
            return None

        lower = heading.lower()

        keywords = (
            "department",
            "faculty",
            "school",
            "institute",
            "centre",
            "center",
        )

        # 1. Prefer heading.
        candidate = heading.strip()

        if any(k in candidate.lower() for k in keywords):
            return candidate

        # 2. Otherwise inspect the first few lines.
        for line in section.get("content", [])[:6]:

            text = line.strip()

            if any(k in text.lower() for k in keywords):

                if len(text) <= 100:
                    return text

        return None
    
    def _looks_like_qualification(
        self,
        line: str,
    ) -> bool:
        """
        Decide whether a line is likely to be
        a qualification of the previously
        detected person.

        Uses generic document structure rather
        than specific degree names.
        """

        text = line.strip()

        if not text:
            return False
        
        # Ignore isolated footnote/page numbers.
        if text.isdigit():
            return False

        if re.fullmatch(
            r"\d+(?:\.\d+)?",
            text,
        ):
            return False

        # Another person's name starts a new record.
        if self.TITLE_PATTERN.search(text):
            return False

        # Roles also start new records.
        if self.ROLE_PATTERN.search(text):
            return False

        # Qualifications are usually concise.
        if len(text) > 120:
            return False
        
        # Headings are not qualifications.
        if text.endswith(":"):
            return False

        # Numbered headings are not qualifications.
        if re.match(
            r"^\d+(\.\d+)*",
            text,
        ):
            return False

        # Institution names, years, commas and
        # parentheses are common in qualifications.
        score = 0

        if "," in text:
            score += 1

        if "(" in text or ")" in text:
            score += 1

        if any(ch.isdigit() for ch in text):
            score += 1

        if len(text.split()) <= 10:
            score += 1

        # Qualifications often mention an institution.
        institution_words = (
            "university",
            "institute",
            "college",
            "school",
        )

        if any(
            word in text.lower()
            for word in institution_words
        ):
            score += 2

        return score >= 3
    
    def _looks_like_person_name(
        self,
        text: str,
    ) -> bool:
        """
        Generic validation for person names.
        """

        text = text.strip()

        if not text:
            return False
        
        # Person names rarely contain digits.
        if any(
            ch.isdigit()
            for ch in text
        ):
            return False

        # Paragraphs are not names.
        if len(text) > 80:
            return False

        # Names are short.
        if len(text.split()) > 8:
            return False

        # Too many commas usually means
        # qualifications or prose.
        if text.count(",") > 1:
            return False

        # Semicolons usually separate qualifications.
        if ";" in text:
            return False
        
        # Reject headings written entirely
        # in uppercase.
        letters = "".join(
            ch
            for ch in text
            if ch.isalpha()
        )

        if (
            letters
            and letters == letters.upper()
        ):
            return False

        # Titles strongly indicate a person.
        if self.TITLE_PATTERN.search(text):
            return True

        return False

    def _is_non_person(
        self,
        text: str,
    ) -> bool:
        """
        Reject obvious facilities or organizations
        that contain a title but are not people.
        """

        text = text.lower()

        blocked = (
            "library",
            "department",
            "faculty",
            "school",
            "centre",
            "center",
            "office",
            "hostel",
            "laboratory",
            "lab",
            "complex",
            "building",
        )

        return any(
            word in text
            for word in blocked
        )
    
    def _extract_people(
        self,
        *,
        section: dict,
        page_number: int,
        heading: str,
    ) -> list[PersonRecord]:

        records: list[PersonRecord] = []
        current_role: str | None = None
        current_person: PersonRecord | None = None

        for line in section.get(
            "content",
            [],
        ):

            line = line.strip()

            line = self._normalize_person_name(
                line
            )

            # Qualification lines belong to the
            # previously detected person.
            if (
                current_person is not None
                and self._looks_like_qualification(
                    line
                )
            ):
                current_person.qualifications.append(
                    line
                )
                continue

            if not line:
                continue

            role_match = self.ROLE_PATTERN.search(
                line
            )

            if role_match:

                # Preserve the complete role line instead
                # of only the matched keyword.
                current_role = line

                continue

            # if self._looks_like_degree(line):
            #     continue

            if not self._looks_like_person_name(
                line
            ):
                continue
            if self._is_non_person(
                line
            ):
                continue

            current_person = PersonRecord(
                name=line,
                role=current_role,
                department=self._extract_department(heading, section),
                qualifications=[],
                source_page=page_number,
                source_heading=heading,
                source_text=line,
            )

            records.append(
                current_person
            )
            current_role = None

        return records